#ifndef TEST_12_H
#define TEST_12_H

#include <QObject>

class Test_12 : public QObject {
Q_OBJECT

public:
    Test_12();
    ~Test_12();
    void runTest();
};

#endif // TEST_12_H
