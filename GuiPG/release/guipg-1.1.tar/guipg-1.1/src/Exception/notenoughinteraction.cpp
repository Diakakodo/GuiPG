#include "notenoughinteraction.h"

NotEnoughInteraction::NotEnoughInteraction(QString msg) : GPGException(msg) {

}

NotEnoughInteraction::~NotEnoughInteraction() {

}

