#include "badinteraction.h"

BadInteraction::BadInteraction(QString msg) : GPGException(msg) {

}

BadInteraction::~BadInteraction() {

}


