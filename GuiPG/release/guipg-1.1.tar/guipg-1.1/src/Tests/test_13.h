#ifndef TEST_13_H
#define TEST_13_H

#include <QObject>

class Test_13 : public QObject {
Q_OBJECT

public:
    Test_13();
    ~Test_13();
    void runTest();
};

#endif // TEST_13_H
